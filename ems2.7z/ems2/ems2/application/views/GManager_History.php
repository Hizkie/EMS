<html>
<head>
<link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css" rel="stylesheet">
    <style>
        #popup1 {
visibility: visible
}
    .button {
font-size: 1em;
color: blue;
cursor: pointer;
transition: all 0.3s ease-out;
  visibility: visible;
  padding: 0,0,0,0;

}
.overlay {
position: fixed;
top: 0;
bottom: 0;
left: 0;
right: 0;
background: rgba(0, 0, 0, 0.7);
transition: opacity 500ms;
visibility: visible;
opacity: 10;
  visibility: visible;

}
.overlay:target {
visibility: visible;
opacity: 1;
  visibility: visible;

}

.popup {
margin: 5px auto;
padding: 0px;
background: #fff;
border-radius: 5px;
width: 60%;
position: relative;
transition: all 5s ease-in-out;
  visibility: visible;
  overflow: scroll;

}

.popup h2 {
margin-top: 0;
color: #333;
font-family: Tahoma, Arial, sans-serif;
  visibility: visible;

}
.popup .close {
position: absolute;
top: 20px;
right: 30px;
transition: all 200ms;
font-size: 30px;
font-weight: bold;
text-decoration: none;
color: #333;
  visibility: visible;

}
.popup .close:hover {
color: #06D85F;
  visibility: visible;

}
.popup .content {
padding-top: 0px;
height:650px;
width: 100%;
overflow: auto;
  visibility: visible;
  position: relative;
}

@media screen and (max-width: 700px){
.box{
width: 100%;
    visibility: visible;

}
@media print{
  .element::-webkit-scrollbar { width: 0 !important }
}
.popup{
width: 100%;
visibility: visible;
}
}

body {
  background-color: #3e94ec;
  font-family: "Roboto", helvetica, arial, sans-serif;
  font-size: 16px;
  font-weight: 400;
  text-rendering: optimizeLegibility;
}


.print{
  margin-left: 500px;
}
img{
  margin-left: 50px;
  margin-top: 50px;
}

h5{
  float: left;
}
.header{
  margin top: 50px;
  height: 40px;
  width: auto;
 }
.header h2{
  text-align: center; 
}
table th{
  font-size:20px;
}
.image{
 position: relative;
 opacity: 0.3;
 width: 100%;
}
.image img{
  padding-top: 0px;
  margin-top: 0px;
  width: 70%;
  height: auto;
  padding-top: 0px;
  margin-top: 0px;
}
tr {
  white-space: nowrap;
}
img{
  width: 100%;
  opacity: 1;
  float: left;
}
.image{
  width: 100%;
  overflow: auto;
  position: absolute;

}

</style>
<script>
    function myFunction(){
         $("#popup1").load();         
     
}
</script>
<script>
function printContent(popup1){
  var restorepage = document.body.innerHTML;
  var printcontent = document.getElementById(popup1).innerHTML;
  document.body.innerHTML = printcontent;
  window.print();
  document.body.innerHTML = restorepage;
}
</script>
</head>
<body>
<?php foreach ($result->result() as $key  ) {?>  
<div id="popup1"> 
     <div class="overlay">
           <div class="popup">
           <div class="header">
            <h2><?php echo $key->Equipment_Name; ?> (Id <?php echo $key->Equipment_Id; ?>) History</h2>
            </div>
              <a class="close" href="<?php echo base_url()?>/GManager/view_equipment">&times;</a>
                   <div class="content">
                   <div class="Image"><?php  echo '<img  src="data:image/png;base64,'.base64_encode($key->Image
                  ).'"/>';  }?>   </div>
                   <table class="table table-striped" Style="margin-left: 0px;"> 
                   <tr class="grow">
                   <td  class="grow"><th >Date Detacted</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td><?php echo $row->Date_Detected; }?></td>
                  </tr>
                   <tr>
                   <td class="grow"><th >Incident Type</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Type; }?></td>
                  </tr>
                  <tr>
                   <td class="grow"><th >Date Incident Occured</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Date_Incident_Occured; }?></td>
                  </tr>
                  <tr>
                   <td class="grow"><th >Location</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Location; }?></td>
                  </tr>
                  <tr>
                   <td class="grow"><th >Entity name</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td cclass="grow"><?php echo $row->Entity_Name; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Description</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Description; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Action taken</th></td>
                  <?php foreach ($incident->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Action_Taken; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Requested by</th></td>
                  <?php foreach ($mr->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Name_of_Requested_Person; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Requested date</th></td>
                  <?php foreach ($mr->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Date; }?></td>
                  </tr>
                  <tr>
                  <td><th >Troubleshoot</th></td>
                  <?php foreach ($mr->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Troubleshoot_Performed; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Description of problem</th></td>
                  <?php foreach ($mr->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Description_of_Problem; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Description of Failer</th></td>
                  <?php foreach ($report->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Description_of_Failer	; }?></td>
                  </tr>
                  <td><th >Cause of Failer</th></td>
                  <?php foreach ($report->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Casuese_of_Failer; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th >Part of Machine</th></td>
                  <?php foreach ($report->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Casuese_of_Failer; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th>Corrective action</th></td>
                  <?php foreach ($report->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Corrective_Action_Taken; }?></td>
                  </tr>
                  <tr>
                  <td class="grow"><th>Spare Part Replaced</th></td>
                  <?php foreach ($report->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Spare_Part_Replaced; }?></td>
                  </tr>
                  <tr>
                   <td><th>Result</th></td>
                  <?php foreach ($report->result() as $row  ) {?> 
                       <td class="grow"><?php echo $row->Result; }?></td>
                  </tr>
                  </table>
                  
                  </div>
                  <button  onclick= "printContent('popup1')" class="noprint btn btn-success print" style="">Print</button>
                </div>
               </div>
               </div>
     </div>
</div>
</body>
</html>

