<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
     <script src="<?php echo base_url();?>assets/js/jquery-1.12.4.js"></script>
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script> 
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script>
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
           <script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
</head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto;">
        <ul class="nav">
         <li><a href="<?php echo base_url();?>equipment/view_man_equipment">Equipment</a></li>
         <li><a href="<?php echo base_url();?>Spare_Part/Spare_Part_Manager">Spare Part</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/job_excussion">Job Execussion</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/view_maintenance_home">Maintenance</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/view_work_order_home">Work order</a></li>
         <li><a href="<?php echo base_url();?>Trainning">Trainning</a></li>
         <li><a href="<?php echo base_url();?>Waranty">Waranty</a></li>
         <li><a class="active" Style="color: white" href="<?php echo base_url();?>Risk_Level">Risk Level</a></li>
        </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li><a href="<?php echo base_url();?>Risk_Level/register_risk_level">Register Risk Level</a></li>
          <li style="font-weight: bold;"><a href="<?php echo base_url();?>Risk_Level/view_risk_level">View Risk Level</a></li>
          <li><a href='<?php echo base_url();?>/Login/Logout'>Logout</a></li>
        </ul>
      </div>
      <div class='span8 main'>
              <table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Equipment Type</th>
                <th>Inventory Number</th>
                <th>Name of assessor</th>
                <th>Date of assessment</th>
                <th>Inventory Classification Result</th>
           </tr>
        </thead>
        <tfoot>
            <tr>
                <th>Equipment Type</th>
                <th>Inventory Number</th>
                <th>Name of assessor</th>
                <th>Date of assessment</th>
                <th>Inventory Classification Result</th>
           </tr>      
        </tfoot>
        <tbody>
            <?php  
           foreach ($query->result() as $key  ) {?>  
       <tr>
         <td> <?php  echo $key->Type_of_Equipment; ?> </td>
         <td> <?php  echo $key->Inventory_Number; ?> </td>
         <td> <?php  echo $key->First_Name; ?> </td>
         <td> <?php  echo $key->Date_of_Assessment; ?> </td>
         <td> <?php  echo $key->Assessment_Result; }?> </td>
       </tr>
       </tbody>
    </table>
    </div>
  </div>
</body>