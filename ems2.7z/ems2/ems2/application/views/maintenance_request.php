<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
      <script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
  </head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto;">
        <ul class="nav">
          <li><a style="color: white; font-weight: bold;" href="<?php echo base_url();?>Maintenance/view_user_home">Maintenance</a></li>
        </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li><a style="font-weight: bold;" href="<?php echo base_url();?>Maintenance">Send Maintenance Request</a></li>
          <li><a href="<?php echo base_url();?>Maintenance/confirm_maintenance">Confirm Maintenance</a></li>
          <li><a href='<?php echo base_url();?>Login/Logout'>Logout</a></li>
        </ul>
      </div>
      <div class='span8 main'>
    <?php         $data = array(
        'cols'        => '20',
        'style'       => 'width:100%',
        'name'        => 'Troubleshoot_Performed'
    ); ?>
          <div class="register"> 
          <h2>Maintenance Reqest</h2> <br> 
          <?php echo form_open("Maintenance/register_maintenance_request");?>
          <p>Troubleshoot Performed</p><?php echo form_textarea($data); ?>
          <p>Equipment Id:</p> 
          <select name="Equipment_Id">
            <?php 
              foreach($query->result() as $row)
            { 
              echo '<option value="'.$row->Equipment_Id.'">'.$row->Equipment_Id.'</option>';
            }
            ?>
            </select>
             <?php echo form_submit('Send_Maintenance_Request', 'Send',''); ?> 
            <?php echo form_close();?>
             <div class="error"> 
                  <?php echo validation_errors() ?>
             </div>
         </div>   
      </div>
    </div>
  </div>
</body>