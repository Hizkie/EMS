<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Risk_Level_Model extends CI_Model{
   function get_id(){
       $query = $this->db->query('select equip.Equipment_Id from equip');
       return $query;
   } 
   function insert_assessment_result($data){
        $query = $this->db->insert('risk_level', $data);  
          if($query){
          return TRUE;
       }
      else {
          return False;
      }
   }
   function view_risk_level(){
       $User_Name = $this->session->userdata('UserName');
       $this->db->where('UserName',$User_Name);
       $query = $this->db->get('account');
       $Id = $query->row()->Staff_Id;
      $result =  $this->db->query("SELECT equip.Type_of_Equipment,equip.Inventory_Number, staf.First_Name, 
               risk_level.Date_of_Assessment, risk_level.Assessment_Result FROM equip,
               risk_level, staf WHERE risk_level.Equipment_Id = equip.Equipment_Id AND
               staf.Staff_Id = '$Id'");
      return $result; 
   }
}
?>