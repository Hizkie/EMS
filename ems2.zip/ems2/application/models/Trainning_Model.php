<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Trainning_Model extends CI_Model{
    function get_user_id(){
        $query= $this->db->query('Select Users.User_Id FROM Users');
        return $query;
    }
    function get_equipment_id(){
       $query =$this->db->query('Select Equipment_Id FROM equip');
        return $query;
    }
    function insert_training($data){
            $query = $this->db->insert('Training', $data);  
          if($query){
          return TRUE;
      }
      else {
          return False;
      }
    }
   function get_trainning(){
       $result = $this->db->query('select training.User_Id, staf.Position, training.Starting_Date, training.Date_of_Training, training.Assessment, 
               training.Equipment_Id, training.Mp_Id, users.User_Id, Users.Staff_Id, Staf.Position, Staf.Department,
               equip.Equipment_Name,equip.Manufacturer , equip.Model, Staf.Date_of_Employment, Staf.First_Name FROM training, users,Staf, map, equip
               WHERE training.Equipment_Id = equip.Equipment_Id AND training.Mp_id = Map.Mp_Id AND  training.User_Id = users.User_Id AND users.Staff_Id = Staf.Staff_Id');
       return $result;
   }
   function get_mp(){
       $result = $this->db->query('select staf.First_Name from training,map,staf WHERE training.Mp_Id = map.Mp_Id AND map.Staff_Id=Staf.Staff_Id');
       return $result;
   }
   function get_Count(){
       $result = $this->db->query("select Status from training WHERE Status= '0'");
       $NumRows = $result->num_rows();
       if($NumRows>0){
          return TRUE;
       }else{
         return FALSE;
       }
   }
   function update_status(){
    $result = $this->db->query(" UPDATE training SET Status = '1'");
   }
}
?>