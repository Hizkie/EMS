<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Litratures extends CI_Model{
    function view(){
             $result=$this->db->query('SELECT 
    equip.Equipment_Name, litrature.User_Manual
FROM 
    litrature
INNER JOIN 
    equip
ON
    litrature.Equipment_Id= equip.Equipment_Id
');
              return $result;
                        
		    }
}
?>