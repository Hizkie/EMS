<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Waranty_Model extends CI_Model{
    function get_equipment_id(){
        $data = $this->db->query('Select Equipment_Id from equip');
        return $data;
    }
    function register_waranty($data){
       $query = $this->db->insert('Waranty', $data);   
      if($query){
          return TRUE;
      }
      else {
          return False;
      }
    
}
function view_waranty(){
    $query = $this->db->query('Select * from equip, waranty WHERE equip.Equipment_Id = waranty.Equipment_Id');
    return $query;
}
}
?>
