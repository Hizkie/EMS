<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Incidents extends CI_Model{
    function get_equipment_id (){
         $query=$this->db->get('equip');
         return $query;
    }
    function register_incidents($data){
      $query = $this->db->insert('incident', $data);   
      if($query){
          return TRUE;
      }
      else {
          return False;
      }
   }
   function get_incidents(){
       $query = $this->db->query('Select * FROM equip, incident WHERE equip.Equipment_Id = incident.Equipment_Id');
       return $query;
               }
} 
?>