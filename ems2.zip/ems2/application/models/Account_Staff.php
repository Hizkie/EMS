<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Account_Staff extends CI_Model{
   function chake_username(){
       $User_Name = $this->input->post('User_Name');
       $this->db->where('UserName',$User_Name);
       $result= $this->db->get('account');
               if($result->num_rows()>=1){
                   return False;
               }else{
                   return TRUE;
               }
   }
   function register_account_staff(){
       $First_Name = $this->input->post('First_Name');
       $Last_Name = $this->input->post('Last_Name');
       $Date_of_Employment = $this->input->post('Date_of_Employement');
       $Department = $this->input->post('Department');
       $Specialization = $this->input->post('Specialization');
       $Experiance = $this->input->post('Experiance');
       $Position = $this->input->post('Position');
       $data = array(
           'First_Name' => $First_Name,
           'Last_Name' => $Last_Name,
           'Position' => $Position,
           'Date_of_Employment' => $Date_of_Employment,
           'Department' => $Department,
           'Experiance' => $Experiance,
           'Specialization' => $Specialization,
       );
      $Staff= $this->db->insert('staff',$data);
      $Id= $this->db->query('Select Staff_Id from staff  ORDER BY Staff_Id DESC LIMIT 1');
      $query = $Id->row()->Staff_Id;
      $User_Name = $this->input->post('User_Name');
      $Password = $this->input->post('Password');
      $data2 = array (
          'UserName' => $User_Name,
          'Password' => $Password,
          'Staff_Id' => $query
      );
      $Account = $this->db->insert('account',$data2);
      if($Account and $Staff){
              echo "<script type='text/javascript'>alert('Data successfuly enterd into database'); window.location.href = 'http://localhost/ems/GManager/Register_Staff'</script>";
      }else{
          echo 'False';
      }
      }
      function view_staff_detail(){
          $query = $this->db->query('Select * from staf');
          return $query;
      }
      function get_staff_Id(){
          $data = $this->db->query('Select Staff_Id from staf');
          return $data;
      }
      function register_mp(){
          $Staff_Id = $this->input->post('Staff_Id');
          $data = array(
              'Staff_Id' => $Staff_Id
          );
          $query = $this->db->insert('map',$data);
          if($query){
            echo "<script type='text/javascript'>alert('Data successfuly enterd into database'); window.location.href = 'http://localhost/ems/GManager/register_mp'</script>";
          }else{
              return FALSE;
          }
      }
}
?>