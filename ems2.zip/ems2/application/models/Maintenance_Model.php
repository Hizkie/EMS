<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Maintenance_Model
 *
 * @author user
 */
class Maintenance_Model extends CI_Model {

    function get_maintenance_request(){
         $query=$this->db->get('equip');
		    return $query;
    }     
    function register_maintenacne_request($data){
         $query = $this->db->insert('maintenance_request', $data);  
          if($query){
          return TRUE;
      }
      else {
          return False;
      }
    }
    function get_maintenance_request_manager(){
         $result=$this->db->query('SELECT equip.Equipment_Id, equip.Inventory_Number , equip.Equipment_Name , equip.Department , equip.Type_of_Equipment , maintenance_request.Maintenance_Request_Id, maintenance_request.Date , maintenance_request.Name_of_Requested_Person, maintenance_request.Date, maintenance_request.Troubleshoot_performed , maintenance_request.Description_of_Problem FROM maintenance_request INNER JOIN equip ON maintenance_request.Equipment_Id= equip.Equipment_Id');
          return $result;
    }
    function get_history(){
        $this->db->where('Equipment_Id', $this->input->post('asa') );
        $query=$this->db->get('equip');
        return $query;
             }
      function get_mp_detail(){
       $result=$this->db->query('SELECT staf.First_Name, Staf.Last_Name, equip.Equipment_Name, assigned_work.date, assigned_work.Priority_of_Task, assigned_work.Status FROM assigned_work, staf, equip, map ,maintenance_request WHERE assigned_work.MP_Id = map.Mp_Id AND map.Staff_Id = staf.Staff_Id AND maintenance_request.Equipment_Id=equip.Equipment_Id AND assigned_work.Mr_Id = maintenance_request.Maintenance_Request_Id');
       return $result;       
   }
   function get_maintenenance_personel(){
       $result=$this->db->query('SELECT Mp_Id from map');
       return $result;
   }
   function get_maintenance_request_Id(){
       $result=$this->db->query('SELECT Maintenance_Request_Id from maintenance_request');
       return $result;
   }
   function register_work_order_db($data){
          $query = $this->db->insert('assigned_work', $data);   
      if($query){
          return TRUE;
      }
      else {
          return False;
      }
   }
   function get_mp_id($UserName){
         $this->db->where('UserName',$UserName);
         $query=$this->db->get('account');
         $Id = $query->row()->Staff_Id;
         $this->db->where('Staff_Id',$Id);
         $result=$this->db->get('map');
         $Mp_Id = $result->row()->Mp_Id;
         $this->db->where('MP_Id',$Mp_Id);
         $solution=$this->db->get('assigned_work');
                           return $solution;
                             }
   function get_mr($UserName){
         $this->db->where('UserName',$UserName);
         $query=$this->db->get('account');
         $Id = $query->row()->Staff_Id;
         $this->db->where('Staff_Id',$Id);
         $result=$this->db->get('mp');
         $Mp_Id = $result->row()->Mp_Id;
         $this->db->where('MP_Id',$Mp_Id);
         $solution=$this->db->get('assigned_work');
         $Mr_Id = $solution->row()->Maintenance_Request_Id;
         $this->db->where('Maintenance_Request_Id',$Mr_Id);
         $maintenance_request=$this->db->get('maintenance_request');
         return $maintenance_request;
   }
   function get_equipment($UserName){
        $this->db->where('UserName',$UserName);
         $query=$this->db->get('account');
         $Id = $query->row()->Staff_Id;
         $this->db->where('Staff_Id',$Id);
         $result=$this->db->get('mp');
         $Mp_Id = $result->row()->Mp_Id;
         $this->db->where('MP_Id',$Mp_Id);
         $solution=$this->db->get('assigned_work');
         $Mr_Id = $solution->row()->Maintenance_Request_Id;
         $this->db->where('Maintenance_Request_Id',$Mr_Id);
         $k = $this->db->get('maintenance_request');
         $equipment_Id = $k->row()->Equipment_Id;
         $this->db->where('Equipment_Id',$equipment_Id);
         $total = $this->db->get('equip');
           return $total;
   }
   function get_work_order($UserName){
       $result=$this->db->query("SELECT assigned_work.Id, assigned_work.Mr_Id, account.Account_Id, Staf.Staff_Id, maintenance_request.Maintenance_Request_Id, map.MP_Id, equip.Equipment_Name, equip.Type_of_Equipment, assigned_work.Priority_of_Task, 
               assigned_work.Date, maintenance_request.Name_of_Requested_Person, maintenance_request.Description_of_Problem, 
               maintenance_request.Troubleshoot_Performed FROM equip, account, assigned_work, maintenance_request , staf, map WHERE 
               account.UserName = '$UserName' AND account.Staff_Id = staf.Staff_Id AND map.Staff_Id=staf.Staff_Id AND maintenance_request.Maintenance_Request_Id=assigned_work.Mr_Id
               AND equip.Equipment_Id = maintenance_request.Equipment_Id;");
       return $result;
   }
   function push_assigned_work(){
              $Ass_Id = $this->input->post('Ass_Id');
               $Mr_Id = $this->input->post('Mr_Id');
          $Insert = array(
                    'Mr_Id' => $Mr_Id,
                    'Reason' => $this->input->post('Reason')
                     );
         $x = $this->db->insert('pushed_work_order', $Insert);
          $y = $this->db->delete('assigned_work', array('id' => $Ass_Id));
          if($x==True && $y==True){
              return TRUE;
          }
         }
         function get_pworkorder(){
             $result = $this->db->query('SELECT * from maintenance_request, pushed_work_order WHERE pushed_work_order.Mr_Id=maintenance_request.maintenance_request_Id');
             return $result;
         }
        function get_requested_spare_part(){
             $result = $this->db->query("SELECT * from spare, spare_part_request WHERE spare_part_request.Spare_Part_Id=spare.Spare_Part_Id AND spare_part_request.status='Unassigned'");
             return $result;
         }
         function get_spare_part(){
             $result = $this->db->query('SELECT * from spare');
             return $result;
         }
         function update_assign_spare_part(){
             $Id= $this->input->post('asa');
            $result = $this->db->query(" UPDATE spare_part_request SET Status = 'Assigned' WHERE spare_part_request.Spare_Part_Request_Id = '$Id' ");
          if($result){
              return TRUE;
          }else{
              return False;
          }
    }
    function assigned_spare_part(){
             $result = $this->db->query("SELECT * from spare_part, spare_part_request WHERE spare_part_request.Spare_Part_Id=spare_part.Spare_Part_Id AND spare_part_request.status='Assigned'");
        return $result;
    }
    function get_mp_and_spare_part_id(){
                              $result = $this->db->query("SELECT Spare_Part_Id FROM spare");
                                return $result;
                              }
    function verify_quantity(){
        $this->db->where('Spare_Part_Id',$this->input->post('Sp_Id'));
        $query=$this->db->get('spare');
        $Quantity = $query->row()->Quantity;
      if($Quantity=$this->input->post('Quantity')){
           return TRUE;
       }else{
           return FALSE;
       }
    }
   function insert_spare_part_request($UserName){
       $this->db->where('UserName',$UserName);
       $query=$this->db->get('account');
       $SId=$query->row()->Staff_Id;
       $this->db->where('Staff_Id',$SId);
       $result=$this->db->get('staf');
       $Fname=$result->row()->First_Name;
        $date = date('y-m-d');
       $data = array(
           'Date'=> $date,
           'Name_of_Mp'=> $Fname,
           'Spare_Part_Id'=>$this->input->post('Sp_Id'),
           'Quantity'=>$this->input->post('Quantity'),
       );
       $final=$this->db->insert('spare_part_request',$data);
       if($final){
           return TRUE;
       }else{
           return FALSE;
       }
         }
    function update_spare_part(){
        $Quantity = $this->input->post('Quantity');
        $this->db->query("update ems.spare set Quantity = Quantity - '$Quantity'");
    }
    function view_assigned_spare_mp($UserName){
        $this->db->where('UserName',$UserName);
        $query=$this->db->get('account');
        $SId=$query->row()->Staff_Id;
        $this->db->where('Staff_Id',$SId);
        $Result=$this->db->get('staf');
        $FirstName=$Result->row()->First_Name;
        $this->db->where('Name_of_Mp',$FirstName);
        $this->db->where('Status','Assigned');
        $Spare_request=$this->db->get('spare_part_request');
        return $Spare_request;   
    }
    function view_assigned_spare_part_mp($UserName){
        $this->db->where('UserName',$UserName);
        $query=$this->db->get('account');
        $SId=$query->row()->Staff_Id;
        $this->db->where('Staff_Id',$SId);
        $Result=$this->db->get('staf');
        $FirstName=$Result->row()->First_Name;
        $this->db->where('Name_of_Mp',$FirstName);
        $this->db->where('Status','Assigned');
        $Spare_request=$this->db->get('spare_part_request');
        $Sp_Id= $Spare_request->row()->Spare_Part_Id;
        $this->db->where('Spare_Part_Id',$Sp_Id);
        $Spare_Part = $this->db->get('spare_part');
        return $Spare_Part;
         }
         function get_assigned_wk(){
             $reuslt = $this->db->query("Select assigned_work.Id FROM assigned_work");
             return $reuslt;
         }
         function send_mr($Id){
       $this->db->where('Id',$Id);
       $result= $this->db->get('assigned_work');
       $Mr_Id = $result->row()->Mr_Id;
       $Mp_Id= $result->row()->MP_Id;
       $Date2 = $result->row()->Date;
       $this->db->where('Maintenance_Request_Id',$Mr_Id);
       $Mr_Table=$this->db->get('maintenance_request');
       $Equipment_Id = $Mr_Table->row()->Equipment_Id;
      $data = array(
        'Description_of_Failer' => $this->input->post('Description'),
        'Casuese_of_Failer' => $this->input->post('Cause_of_Failer'),
        'Part_of_Machine' => $this->input->post('Part_of_Machine'),
        'Corrective_Action_Taken' => $this->input->post('Corrective_Action_Taken'),
        'Result' => $this->input->post('Result'),
        'Spare_Part_Replaced' => $this->input->post('Spare_Part'),
        'Assigned_Work_Id' => $Id,
        'Equipment_Id' => $Equipment_Id,
        'Mp_Id' => $Mp_Id
      );
      $x= $this->db->insert('maintenance_report',$data);
      $Date= date('y-m-d');
       $this->db->query("SET @result=DATEDIFF('$Date', '$Date2');");
       $y=$this->db->query("UPDATE maintenance_report SET Time_Required = @result;");
       if($x && $y){
           return TRUE;
       }else{
           return FALSE;
       }
         }
         function get_executed_job(){
            $query = $this->db->query("select Description_of_Failer, Casuese_of_Failer, Part_of_Machine, Corrective_Action_Taken, 
                     Time_Required, Maintenance_Report_Id, Id,staf.First_Name,  Spare_Part_Replaced, Result, equip.Equipment_Name, equip.Type_of_Equipment, equip.Inventory_Number, 
                     equip.Model, equip.Serial_Number, maintenance_request.Name_of_Requested_Person FROM assigned_work, maintenance_report, staf, equip, maintenance_request, map 
                     WHERE maintenance_report.Assigned_Work_Id=assigned_work.Id AND maintenance_report.Equipment_Id=equip.Equipment_Id AND maintenance_report.Mp_Id=map.Mp_Id AND map.Staff_Id = staf.Staff_Id and assigned_work.Mr_Id = maintenance_request.Maintenance_Request_Id");
            return $query;
         }
         function get_executed_job_by_id($Id){
             $query = $this->db->query("select Description_of_Failer, Casuese_of_Failer, Part_of_Machine, Corrective_Action_Taken, 
                     Time_Required, Maintenance_Report_Id, Id,staf.First_Name,  Spare_Part_Replaced, Result, equip.Equipment_Name, equip.Type_of_Equipment, equip.Inventory_Number, 
                     equip.Model, equip.Serial_Number, maintenance_request.Name_of_Requested_Person FROM assigned_work, maintenance_report, staf, equip, maintenance_request, map 
                     WHERE Maintenance_Report_Id = '$Id' AND maintenance_report.Assigned_Work_Id=assigned_work.Id AND maintenance_report.Equipment_Id=equip.Equipment_Id AND maintenance_report.Mp_Id=map.Mp_Id AND map.Staff_Id = staf.Staff_Id and assigned_work.Mr_Id = maintenance_request.Maintenance_Request_Id");
             return $query;
         }
         function change_status($data){
             $As_Id = $this->input->post('Ass_Id');
            $query = $this->db->query("UPDATE assigned_work SET Status = '$data' WHERE Id = '$As_Id'");
            return $query;
             }
             function get_equiman_Id(){
                $query = $this->db->query("select MP_Id, Equipment_Id from equip , map");
                return $query;
             }
             function set_schedual($data){
                 $query = $this->db->insert('preventive_maintenance',$data);
                 if($query){
                    return TRUE;
            }else{
                    return FALSE;
            }
             }
             function get_mp(){
                $Now = date('y-m-d');
               $this->db->Where('Date',$Now);
               $this->db->Where('Status',0);
               $row= $this->db->get('preventive_maintenance');
               $result = $row->num_rows();
               if($result>0){
                   return TRUE;
               } else{
                   return FALSE;
               }
             } 
             function get_count(){
                $Now = date('y-m-d');
                $this->db->Where('Date',$Now);
                $this->db->Where('Status',0);
                $row= $this->db->get('preventive_maintenance');
                $result = $row->num_rows();
               return $result;
             }
             function get_mp_ids(){
                 $query = $this->db->query('Select MP_Id from map');
                 return $query;
             }
             function assign_pm($data){
                $query = $this->db->insert('assigned_preventive', $data);  
                if($query){
                return TRUE;
            }
            else {
                return False;
            }
             }
             function update_status_pm(){
                 $this->db->query("UPDATE preventive_maintenance SET Status = '1'");
             }
             function pm_workorder_status(){
                $this->db->Where('Status',0);
                $row = $this->db->get('assigned_preventive');
                if($row->num_rows()>0){
                    return TRUE;
                }else{
                    return FALSE;
                }
             }
             function pm_workorder_count(){
                $this->db->Where('Status',0);
                $row = $this->db->get('assigned_preventive');
                $count = $row->num_rows();
                return $count;
             }
             function change_pm_status(){
                $this->db->query("UPDATE assigned_preventive SET Status = '1'");
             }
             function get_pm_data(){
                $query = $this->db->query("SELECT * assigned_preventive");
                return $query;
             }
             function get_user_maintenance_request($UserName){
                $this->db->where("Name_of_Requested_Person","fvf");
                $query = $this->db->get("maintenance_request");
                if($query->num_rows()>0){
                $mr_id=$query->row()->Maintenance_Request_Id;
                $this->db->where("Mr_Id",$mr_id);
                $query2= $this->db->get("assigned_work");
                if($query->num_rows()>0){
                $status = $query2->row()->Status;
                $this->db->where("Status","Executed");
                $this->db->where("Mr_Id",$mr_id);
                $excution = $this->db->get("assigned_work");
                if($excution->num_rows>0){
                $Id = $excution->row()->Mr_Id;
                return  $excution;
                }else{
                    return FALSE;
                }
                   
                }ELSE{
                    RETURN FALSE;
                }
                } ELSE{
                    RETURN FALSE;
                }
                
                }
             
             function confirm_maintenance($data){
                 $query = $this->db->insert("maintenance_accepted_equipment",$data);
                 if($query){
                     return TRUE;
                 }else{
                      return FALSE;
                 }
                 
             }
             function change_excussion_status($Id){
                 $this->db->where("Mr_Id",$Id);
                 $data = array(
                     "Status"=> 'Accepted'
                 );
                 $query = $this->db->update("assigned_work",$data);
                 if($query){
                     return TRUE;
                 }else{
                     return FALSE;
                 }
             }
}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            