<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class equipments extends CI_Model{
    function view(){
             $query=$this->db->get('equip');
		    return $query;
            }
    function register_equipment($imgdata){
        $imgdata = $imgdata['full_path'];// get the path of the image
        $data = array(
                'image' => $imgdata,// change the type of image from blob to varchar or text
        );
               $this->db->update('equip', $data);
            }
  function set_Image($path, $post){
        $val = array(
                'Inventory_Number' =>$this->input->post('Inventory_Number'),
                'Equipment_Name' => $this->input->post('Equipment_Name'),
                'Model' => $this->input->post('Model'),
                'Department' =>$this->input->post('Department'),
                'Type_of_Equipment' =>$this->input->post('Equipment_Type'),
                'Serial_Number' =>$this->input->post('Serial_Number'),
                'Country_of_Origin' =>$this->input->post('Country_of_Origin'),
                'Year_of_Manufacture' =>$this->input->post('Manufactured_Year'),
                'Installation_Date' =>$this->input->post('Installation_Date'),
                'Power_Requierment' =>$this->input->post('Power_Requierment'),
                'Shelf_Life_Time' =>$this->input->post('Shelf_Life_Time'),
                'Current_State' =>$this->input->post('Current_State'),
                'Manufacturer' =>$this->input->post('Manufacturer'),
                'Image' => $path
        );
        $this->db->insert('equip', $val); 
  }
  function get_equipment(){
        $query = $this->db->query('SELECT * from equip');
        return $query;
  }
  function get_equip_data($data){
          $query = $this->db->query("SELECT * from equip WHERE equip.Equipment_Id='$data'");
          return $query;
  }
  function get_query($data){
        $query = $this->db->query("SELECT * from incident WHERE incident.Equipment_Id = '$data'");
        return $query;
  }
  function get_mr($data){
      $query = $this->db->query("SELECT * from  maintenance_request WHERE maintenance_request.Equipment_Id = '$data' ");
      return $query;
  }
  function get_waranty($data){
      $query = $this->db->query("SELECT * from waranty WHERE waranty.Equipment_Id = '$data' ");
      return $query;
  }
  function get_mreport($data){
    $query = $this->db->query("SELECT * from maintenance_report WHERE maintenance_report.Equipment_Id = '$data'");
    return $query;
  }
  function get_equip_id(){
        $query = $this->db->query("SELECT Equipment_Id from equip");
        return $query;
  }
function set_spare($data){
    $query= $this->db->insert('spare', $data);
    if($query){
            return TRUE;
    }else{
            return FALSE;
    }

} 
function view_schedual($UserName){
        $this->db->where('UserName',$UserName);
        $query=$this->db->get('account');
        $Id = $query->row()->Staff_Id;
        $this->db->where('Staff_Id',$Id);
        $result=$this->db->get('map');
        $Mp_Id = $result->row()->MP_Id;
        $this->db->where('MP_Id',$Mp_Id);
        $this->db->where('Status',0);
        $result=$this->db->get('assigned_preventive');
        if($result->num_rows()>0){
                return TRUE;
        }else{
                return FALSE;
        }
                          
                            }
function get_new_preventive_count($UserName){
        $this->db->where('UserName',$UserName);
        $query=$this->db->get('account');
        $Id = $query->row()->Staff_Id;
        $this->db->where('Staff_Id',$Id);
        $result=$this->db->get('map');
        $Mp_Id = $result->row()->MP_Id;
        $this->db->where('MP_Id',$Mp_Id);
        $this->db->where('Status',0);
        $result=$this->db->get('assigned_preventive');
        return $result->num_rows();
}
function get_equipment_id(){
        $query = $this->db->query("SELECT equip.Equipment_Id from equip");
        return $query;
} 
function register_acceptance_sheet($data){
        $query= $this->db->insert('acceptance', $data);
        if($query){
                return TRUE;
        }else{
                return FALSE;
        }
    
}
function view_acceptance(){
        $query = $this->db->query('Select * FROM acceptance');
        return $query;
}
function get_preventive($UserName){
        $this->db->where('UserName',$UserName);
        $query=$this->db->get('account');
        $Id = $query->row()->Staff_Id;
        $this->db->where('Staff_Id',$Id);
        $result=$this->db->get('map');
        $Mp_Id = $result->row()->MP_Id;
        $this->db->where('MP_Id',$Mp_Id);
        $result2=$this->db->get('assigned_preventive');
        $Equip_Id = $result2->row()->Equipment_Id;
        $this->db->where('Equipment_Id',$Equip_Id);
        $query = $this->db->get('equip');
        return $query;
}
function update_preventive_status($UserName){
        $data = array(
                'Status' => 1,
        );
        $this->db->where('UserName',$UserName);
        $query=$this->db->get('account');
        $Id = $query->row()->Staff_Id;
        $this->db->where('Staff_Id',$Id);
        $result=$this->db->get('map');
        $Mp_Id = $result->row()->MP_Id;
        $this->db->where('MP_Id',$Mp_Id);
        $this->db->where('Status',0);
        $this->db->update('assigned_preventive', $data);
}

}
