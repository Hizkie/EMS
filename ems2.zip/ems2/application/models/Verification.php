<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class verification extends CI_Model{
         private function no_cache(){
       
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        
    }
    public function __construct() {	
      parent::__construct();
	$this->no_cache();				
	}
    function verify(){
                $this->db->where('UserName',$this->input->post('UserName'));
		$this->db->where('Password',$this->input->post('Password'));
		$query=$this->db->get('account');
		if($query->num_rows()==1){
			return $query;
		}		
                }
             function get_position(){
                 $this->db->where('UserName',$this->input->post('UserName'));
                 $query=$this->db->get('account');
                 $Id = $query->row()->Staff_Id;
                 $this->db->where('Staff_Id',$Id);
                 $result=$this->db->get('staf');
                 $position = $result->row()->Position;
                  return $position;
                             }
}
