<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Class Incident Extends CI_Controller{
       public function Index(){
           $this->load->view('Incident');
       }
       public function mp_incident(){
        $this->load->model('equipments');
        $UserName = $this->session->userdata('UserName');
        $query= $this->equipments->view_schedual($UserName);
               if($query){
            $data['count'] = $this->equipments->get_new_preventive_count($UserName);
            $this->load->view('mp_incident',$data);
        }else{
          $this->load->view('mp_incident');
        }
          
       }
       public function register_incident(){
            $this->load->model('incidents');
            $data['Equipment_Id'] = $this->incidents->get_equipment_id();
               $this->load->view('register_incident',$data);
       }
       public function register_incident_db(){
                $UserName = $this->session->userdata('UserName');
                $data = array(
                'Type' => $this->input->post('Incident_Type'),
                'Date_Detected' => $this->input->post('Date_Detected'),
                'Date_Incident_Occured' => $this->input->post('Incident_Date'),
                'Location' => $this->input->post('Location'),
                'Entity_Name' => $UserName,
                'Description' => $this->input->post('Description'),
                'Action_Taken' => $this->input->post('Action_Taken'),
                'Equipment_Id' => $this->input->post('Equipment_Id')
);
             $this->load->model('incidents');
             $result=$this->incidents->register_incidents($data);
             if($result){
              echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Incident/register_incident'</script>";
             }else{
                echo "<script type='text/javascript'>alert('Data is not stored in database please try again'); window.location.href = 'http://localhost/ems/Incident/register_incident'</script>";
             }
           }
           function view_incident(){
             $this->load->model('incidents');
             $data['result']=$this->incidents->get_incidents();
             $this->load->view('view_incident', $data);
           }
           function view_man_incident(){
               $this->load->model('incidents');
             $data['result']=$this->incidents->get_incidents();
             $this->load->view('view_man_incident', $data);
           }
}
     ?>