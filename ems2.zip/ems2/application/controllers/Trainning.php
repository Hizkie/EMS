<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Trainning extends CI_Controller{
    public function  index(){
        $this->load->model('Trainning_Model');
        $result = $this->Trainning_Model->get_Count();
        if($result){
            $data["New"]="New";
     $this->load->view('man_training_home',$data);   
    }else{
        $this->load->view('man_training_home');   
    }
}
    function register_trainning_home(){
        $this->load->model('Trainning_Model');
        $data1['query']= $this->Trainning_Model->get_user_id();
        $data2['result']= $this->Trainning_Model->get_equipment_id();
        $data = $data1 + $data2;
        $this->load->view('register_trainning_home',$data);   
      
    }
    function register_trainning(){
        $this->form_validation->set_rules('Assessment', 'Assessment', 'trim|required');
          if($this->form_validation->run()==FALSE){
                 $this->register_trainning_home();    
                 }else{
                     $Startting_Date = $this->input->post('Starting_Date');
                     $Date_of_Trainnig = $this->input->post('Date_of_Trainnig');
                     $Assessment = $this->input->post('Assessment');
                     $Equipment_Id = $this->input->post('Equipment_Id');
                     $User_Id = $this->input->post('User_Id');
                     $data = array(
                         'Starting_Date' => $Startting_Date,
                         'Date_of_Training' => $Date_of_Trainnig,
                         'Assessment' => $Assessment,
                         'User_Id' => $User_Id,
                         'Equipment_Id' => $Equipment_Id
                     );
        $this->load->model('Trainning_Model');
        $query = $this->Trainning_Model->insert_training($data);
        if($query){
                  echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Trainning/register_trainning_home'</script>";

        }else{
                 echo "<script type='text/javascript'>alert('Failed to insert'); window.location.href = 'http://localhost/ems/Trainning/register_trainning_home'</script>";
        }
                     }
    }
    function view_trainning_detail(){
        $this->load->model('Trainning_Model');
        $data1['result'] = $this->Trainning_Model->get_trainning();
        $data2['query'] = $this->Trainning_Model->get_mp();
       $this->Trainning_Model->update_status();
         $data = $data1 + $data2;
        $this->load->view('view_training_detail',$data);
     
    }
}
?>