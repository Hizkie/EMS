<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Risk_Level extends CI_Controller{
  function index(){
    $this->load->view('man_risk_level');
}
function register_risk_level(){
    $this->load->model('Risk_Level_Model');
    $data['Risk_Level']=$this->Risk_Level_Model->get_id();
    $this->load->view('Register_Risk_Level',$data);
}
function register_rl_db(){
    $Equipment_Function=  $this->input->post('Equipment_Function');
    $Associated_Risk = $this->input->post('Associated_Risk');
    $Preventive_Maintenance_Requierment = $this->input->post('Preventive_Maintenance_Requierment');
    $Likelihood_of_Failer = $this->input->post('Likelihood_of_Failer');
    $main_area_of_equipment_use = $this->input->post('main_area_of_equipment_use');
    switch($Equipment_Function){
        case 'therapeutic_life_support':
            $Equipment_Function = 10;
            break;
        case 'therapeutic_surgicalor_intencive_care':
           $Equipment_Function=9;
            break;
        case 'therapeutic_physical_therapy_or_treatment':
            $Equipment_Function= 8;
            break;
        case 'diagnostic_surgical_or_intensive_care_monitoring':
            $Equipment_Function= 7;
            break;
        case 'diagnostic_other_physiological_monitoring':
            $Equipment_Function = 6;
            break;
        case 'analytical_laboratory_analytical':
            $Equipment_Function = 5;
            break;
        case 'analytical_laboratory_accessories':
            $Equipment_Function = 4;
            break;
        case 'analytical_computer_and_related':
            $Equipment_Function = 3;
            break;
        case 'miscellaneous_patient_related':
            $Equipment_Function = 2;
            break;
        case 'Miscellaneous – non-patient related':
            $Equipment_Function = 1;
    }
    switch($Associated_Risk){
        case 'potential_patient_death':
            $Associated_Risk = 5;
            break;
        case 'potential_patient_injury':
            $Associated_Risk = 4;
            break;
        case 'inappropriate_therapy_or_misdiagnosis':
            $Associated_Risk = 3;
            break;
        case 'equipment_damage':
            $Associated_Risk = 2;
            break;
        case 'no_significant_identified_risk':
            $Associated_Risk = 1;
    }
        switch ($Preventive_Maintenance_Requierment){
            case 'monthly':
                $Preventive_Maintenance_Requierment = 5;
            case 'quarterly':
                $Preventive_Maintenance_Requierment = 4;
                break;
            case 'semi-annually':
                $Preventive_Maintenance_Requierment = 3;
                break;
            case 'annually':
                $Preventive_Maintenance_Requierment = 2;
                break;
            case 'not_required':
                $Preventive_Maintenance_Requierment = 1;
        }
        switch ($Likelihood_of_Failer){
            case 'less_than_three_months':
                $Likelihood_of_Failer = 5;
                break;
            case 'approximately_4_6_months':
                 $Likelihood_of_Failer = 4;
                break;
            case 'approximately_7_months_to_1_year':
                 $Likelihood_of_Failer = 3;
                break;
            case 'approximately_1_to_3_years':
                 $Likelihood_of_Failer = 2;
                break;
            case 'approximately_more_3_years':
                 $Likelihood_of_Failer = 1;
        }
        switch ($main_area_of_equipment_use){
            case 'anesthesia_care':
                $main_area_of_equipment_use = 5;
                break;
            case 'critical_care':
                 $main_area_of_equipment_use = 4;
                 break;
            case 'labs_areas':
                 $main_area_of_equipment_use = 3;
                   break;
            case 'general_care_areas':
                 $main_area_of_equipment_use = 2;
                break;
            case 'non_patient_areas':
                 $main_area_of_equipment_use = 1;
                break;
        }
  $result1 = $Preventive_Maintenance_Requierment+$Likelihood_of_Failer+$main_area_of_equipment_use;
  $result2 = $result1/3;
  $result = (int)$Equipment_Function + (int)$Associated_Risk + (int)$result2;
                  if($result>=18){
                                $result = 'High risk';
                                } elseif ($result>=15) {
                                    $result = 'Medium Risk';
                                  }else if($result>=12){
                                    $result = 'Low risk';
                                  }else if($result<12){
                                     $result = 'Hazard Survielance';
                                  }
            $UserName = $this->session->userdata('UserName');
            $Assessment_Result = $result;
            $date = date('y-m-d');
            $Equipment_Id = $this->input->post('Equipment_Id');
            $data = array(
               'Assessment_Result' =>  $Assessment_Result,
                'Date_of_Assessment' => $date,
                'Equipment_Id' => $Equipment_Id,
                'User_Name' => $UserName 
            );
            $this->load->model('Risk_Level_Model');
           $query= $this->Risk_Level_Model->insert_assessment_result($data);
           if($query){
                  echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Risk_Level/register_risk_level'</script>";
           }else{
                 echo "<script type='text/javascript'>alert('Data failed! to insert into database'); window.location.href = 'http://localhost/ems/Risk_Level/register_risk_level'</script>";

           }
            }
            function view_risk_level(){
                $this->load->model('Risk_Level_Model');
                $data['query'] = $this->Risk_Level_Model->view_risk_level();
                $this->load->view('view_risk_level',$data);
            }
}