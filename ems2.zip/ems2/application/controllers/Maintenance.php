<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Maintenance
 *
 * @author user
 */
class Maintenance extends CI_Controller{
    function Index(){
        $this->load->model('Maintenance_Model');
        $data['query']=$this->Maintenance_Model->get_maintenance_request();
        $this->load->view('maintenance_request',$data);
    }
    function confirm_maintenance(){
        $this->load->model('Maintenance_Model');
        $UserName = $this->session->userdata('UserName');
        $data['query']=$this->Maintenance_Model->get_user_maintenance_request($UserName);
        if(isset($data)){
             $this->load->view("confirm_maintenance",$data);
        }else{
            $this->load->view("confirm_maintenance");
        }
        
        
    }
    function from_view_confirm_maintenance(){
               $this->load->model('Maintenance_Model'); 
               $Id = $this->input->post("Equipment_Id");
               $data = array(
                    "Mr_Id"=> $this->input->post("Equipment_Id"),
                    "Date" => date('y-m-d')
                   );
               if(isset($_POST['Confirm'])){
                 $result= $this->Maintenance_Model->confirm_maintenance($data);
                 if($result){
                   $result2 = $this->Maintenance_Model->change_excussion_status($Id);
                   if($result2){
               echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Maintenance/confirm_maintenance'</script>";
                   }
                 }
                   }else{
                   echo "reject";
               }
               $Id = $this->session->userdata('UserName');
                 
    }
    function register_maintenance_request(){
       $this->form_validation->set_rules('Troubleshoot_Performed', 'User name', 'trim|required');
       if($this->form_validation->run()==FALSE){
           $this->index();
           }
            else{ 
             $UserName = $this->session->userdata('UserName');
             $date = date('y-m-d');
                $data = array(  
                'Name_of_Requested_Person' => $UserName,
                'Date' => $date,
                'Troubleshoot_Performed' => $this->input->post('Troubleshoot_Performed'),
                'Equipment_Id' => $this->input->post('Equipment_Id'),
); 
                 $this->load->model('Maintenance_Model');
                 $result = $this->Maintenance_Model->register_maintenacne_request($data);
                   if($result){
              echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Maintenance/register_maintenance_request'</script>";
             }else{
                echo "<script type='text/javascript'>alert('Data is not stored in database please try again'); window.location.href = 'http://localhost/ems/Maintenance/register_maintenance_request'</script>";
             }
                 }
                  
    }
    function job_excussion(){
        $this->load->view('Job_Execussion');
           }
    function prepare_job_execusion_report(){
      $this->load->model('maintenance_model');
      $data['result']=$result= $this->maintenance_model->get_assigned_wk();  
      $this->load->view('prepare_job_execussion_report',$data); 
    }
    function send_maintenance_report(){
       $this->form_validation->set_rules('Description', 'Description of failer', 'trim|required');
       $this->form_validation->set_rules('Cause_of_Failer', 'Cause of failer', 'trim|required');
       $this->form_validation->set_rules('Part_of_Machine', 'Part of machine', 'trim|required');
       $this->form_validation->set_rules('Result', 'Result', 'trim|required');
       $this->form_validation->set_rules('Corrective_Action_Taken', 'Corrective action', 'trim|required');
       $this->form_validation->set_rules('Spare_Part', ' Spare Part', 'trim|required');
         if($this->form_validation->run()==FALSE){
         $this->prepare_job_execusion_report();
         }else{
        $Id = $this->input->post('Id');
        $this->load->model('maintenance_model');
        $result= $this->maintenance_model->send_mr($Id);
        IF($result){
            echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Maintenance/prepare_job_execusion_report'</script>"; 
        }
            echo "<script type='text/javascript'>alert('Failed!'); window.location.href = 'http://localhost/ems/Maintenance/prepare_job_execusion_report'</script>";
         }
         
    }
    function mp_job_excussion(){
        $this->load->view('mp_job_excussion');
    }
   function view_user_home(){
       $this->load->view('user');
   }
    //put your code here
}
 
   