<?php 
   class Spare_Part extends CI_Controller{
       function index(){
           $this->load->view('Spare_Part');
       }
       function spare_part_manager(){
           $this->load->view("Spare_Part_Manager");
       }
       function view_sparepart_detail(){
        $this->load->model('Maintenance_Model');
        $data['result']=$this->Maintenance_Model->get_spare_part();
        $this->load->view('Spare_Part_Detail',$data);
   }
   function view_assign_spare_part(){
         $this->load->model('Maintenance_Model');
         $data['result'] = $this->Maintenance_Model->assigned_spare_part();
         $this->load->view('view_assigned_spare_part',$data);
    } 
       function send_spare_part(){
           $UserName = $this->session->userdata('UserName');
           $this->load->model('Maintenance_Model'); 
           $data['result']=$this->Maintenance_Model->get_mp_and_spare_part_id($UserName);
           $this->load->view('Send_Spare_Part_Request',$data);
       }
       function send_spare_part_db(){
           $this->form_validation->set_rules('Quantity', 'Quantity', 'trim|required');
          if($this->form_validation->run()==FALSE){
                 $this->send_spare_part();          
                      }
                 else{
           $UserName = $this->session->userdata('UserName');
           $this->load->model('Maintenance_Model'); 
           $result=$this->Maintenance_Model->verify_quantity();
           if($result){
            $query=$this->Maintenance_Model->insert_spare_part_request($UserName);
            $result=$this->Maintenance_Model->update_spare_part();
              echo "<script type='text/javascript'> alert('Your operation was successful'); window.location.href = 'http://localhost/ems/Spare_Part/send_spare_part'</script>";
           }else{
              echo "<script type='text/javascript'> alert('That mach quantity is not available in store'); window.location.href = 'http://localhost/ems/Spare_Part/send_spare_part'</script>";
                 }
           }
   }
          function view_assigned_spare_part(){
            $UserName = $this->session->userdata('UserName');
            $this->load->model('Maintenance_Model'); 
            $data1['result']=$this->Maintenance_Model->view_assigned_spare_mp($UserName);
            $data2['query']=$this->Maintenance_Model->view_assigned_spare_part_mp($UserName);
            IF($data2){
                $data = $data1 + $data2;
            $this->load->view('Assign_Spare_Part',$data);}else{
                echo 'error';
            }
            }
   function return_spare_part(){
           $Sp_Id = $this->input->post('Spr_Id');
           $this->load->model('Maintenance_Model'); 
          $result=$this->Maintenance_Model->return_sp($Sp_Id);
          if($result){
         echo "<script type='text/javascript'> alert('Your operation was successful'); window.location.href = 'http://localhost/ems/Spare_Part/view_assigned_spare_part'</script>";
          }else{
           echo "<script type='text/javascript'> alert('Fail! Your operation was unsuccessful'); window.location.href = 'http://localhost/ems/Spare_Part/view_assigned_spare_part'</script>";
          }
         
            }
    function view_requested_spare_part(){
       $this->load->model('Maintenance_Model');
       $data['result']=$this->Maintenance_Model->get_requested_spare_part();
       $this->load->view('View_Spare_Part_Request',$data);
   }
      
   function assign_spare_part(){
     $this->load->model('Maintenance_Model');
     $query = $this->Maintenance_Model->update_assign_spare_part();
     if($query){
        echo "<script type='text/javascript'> alert('Your operation was successful'); window.location.href = 'http://localhost/ems/Spare_Part/View_requested_spare_Part'</script>";
     }else{
         echo "<script type='text/javascript'> alert('The operation was failed'); 'http://localhost/ems/Spare_Part/View_requested_spare_Part'</script>";
     }
         }
         function mp_assigned_spare_part(){
       $this->load->model('Maintenance_Model');
       $data['result']=$this->Maintenance_Model->get_requested_spare_part();
       $this->load->view('mp_assigned_spare_part',$data);
         }
   }
   
?>