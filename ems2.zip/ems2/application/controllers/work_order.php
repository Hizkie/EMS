<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class work_order extends CI_Controller{
                function index(){
                $this->load->view('work_order');
             }
function view_work_order(){
    $this->load->model('Maintenance_Model');
    $result = $this->Maintenance_Model->pm_workorder_status();
    if($result){
          $data['count'] = $this->Maintenance_Model->pm_workorder_count();
          $this->load->view('view_work_order',$data);
    }else{
        $this->load->view('view_work_order');
    }
                 
    }
   function push(){
      if($this->input->post('Push') == "Push") {
     $data1['Ass_Id']=$this->input->post('Ass_Id');
     $data2['Mr_Id']= $this->input->post('Mr_Id');
     $data = $data1+ $data2; 
     $this->load->view('Push', $data);  
      }else{
        $data['Ass_Id']=$this->input->post('Ass_Id');
        $this->load->view('Change_Status', $data);  
      }
    }
   function push_assigned_work(){
       $this->load->model('Maintenance_Model');
       $result=$this->Maintenance_Model->push_assigned_work();
       if($result){
            echo "<script type='text/javascript'>alert('Your operation was successful'); window.location.href = 'http://localhost/ems/work_order/view_work_order'</script>";
       }else{
            echo "<script type='text/javascript'>alert('Error'); window.location.href = 'http://localhost/ems/work_order/view_work_order'</script>";
       }
   }
   function pushed_work_order(){
       $this->load->model('Maintenance_Model');
       $data['result'] = $this->Maintenance_Model->get_pworkorder();
       $this->load->view('pushed_work_order',$data);
   }
   function change_status(){
       $this->load->model('Maintenance_Model');
       $Status = $this->input->post('Status');
      $result = $this->Maintenance_Model->change_status($Status);
      if($Status == "Started"){
        echo "<script type='text/javascript'>alert('The job is started'); window.location.href = 'http://localhost/ems/work_order/view_work_order_mp'</script>";
      }else{
          $this->prepare_job_execusion_report();
      }
   }
   function view_work_order_mp(){
       $UserName = $this->session->userdata('UserName');
                  $this->load->model('Maintenance_Model');
                  $data['result']=$this->Maintenance_Model->get_work_order($UserName);
                  $this->load->view('view_work_order_mp',$data);
   }
   function prepare_job_execusion_report(){
    $this->load->model('maintenance_model');
    $data['result']= $this->maintenance_model->get_assigned_wk();  
    $this->load->view('prepare_job_execussion_report',$data); 
  }
  function view_work_preventive_order_mp(){
    $this->load->model('maintenance_model');
    $this->maintenance_model->change_pm_status();
    $data['result']=$this->maintenance_model->get_pm_data();
    $this->load->view('view_work_preventive_order_mp',$data); 
 }
}
?>