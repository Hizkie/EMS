<?php 
class modal extends CI_Controller{
    function Index(){
        $this->load->view('modal2.php');
    }
    function modals(){
        $this->load->view('modal.php');
    }
}

?>