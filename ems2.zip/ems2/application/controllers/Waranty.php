<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Waranty extends CI_Controller{
    function index(){
        $this->load->view('Waranty_Home');
    }
    function register_waranty(){
        $this->load->model('Waranty_Model');
       $data['eq_id'] =  $this->Waranty_Model->get_equipment_id();
       $this->load->view('register_waranty',$data);
    }
    function register_waranty_db(){
        $this->form_validation->set_rules('Waranty_Start_Date', 'Waranty Start Date', 'trim|required');
        $this->form_validation->set_rules('Waranty_Expiry_Date', 'Waranty Expiry Date', 'trim|required');
        $this->form_validation->set_rules('Maintenance_Contract_Signed_With', 'Maintenance Contract Signed With', 'trim|required');
        $this->form_validation->set_rules('Address', 'Address', 'trim|required');
        $this->form_validation->set_rules('Telephone', 'Telephone', 'trim|required');
        $this->form_validation->set_rules('Equipment_Id', 'Equipment_Id', 'trim|required');
        $this->form_validation->set_rules('Maintenance_Contract_Signed_With', 'Maintenance Contract Signed With', 'trim|required');
          if($this->form_validation->run()==FALSE){
              $this->register_waranty();
          }else{
         $Service = $this->input->post('Service');
        $Waranty_Starting_Date = $this->input->post('Waranty_Start_Date');
        $Waranty_Expiry_Date = $this->input->post('Waranty_Expiry_Date');
        $Maintenance_Contract_Signed_With = $this->input->post('Maintenance_Contract_Signed_With');
        $Address = $this->input->post('Address');
        $Telephone = $this->input->post('Telephone');
        $Equipment_Id = $this->input->post('Equipment_Id');
     $data = array(
         'Waranty_Service' => $Service,
         'Waranty_Start_Date' => $Waranty_Starting_Date,
         'Waranty_Expiry_Date' => $Waranty_Expiry_Date,
         'Maintenance_Contract_Signed_With' => $Maintenance_Contract_Signed_With,
         'Address' => $Address,
         'Telephone' => $Telephone,
         'Equipment_Id' => $Equipment_Id
     );
     $this->load->model('Waranty_Model');
   $query = $this->Waranty_Model->register_waranty($data);
  if($query){
       echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Waranty/register_waranty'</script>";
 }else{
      echo "<script type='text/javascript'>alert('Failed to insert into database'); window.location.href = 'http://localhost/ems/Waranty/register_waranty'</script>";
   }
          }

    }
    function view_man_waranty(){
        $this->load->model('Waranty_Model');
        $data['query'] =  $this->Waranty_Model->view_waranty();
        $this->load->view('view_man_waranty',$data);
    }
} 
?>