<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Maintenance_Manager
 *
 * @author user
 */

class Maintenance_Manager extends CI_Controller {
   function index(){
          $this->load->view('Manager');
    }
    function view_maintenance_request(){
         $this->load->model('Maintenance_Model');
         $data['result'] = $this->Maintenance_Model->get_maintenance_request_manager();
         $this->load->view('View_Maintenance_Request', $data);
    }
    function view_mp_detail(){
         $this->load->model('Maintenance_Model');
         $data['result'] = $this->Maintenance_Model->get_mp_detail();
         $this->load->view('View_mp_detail', $data);
    }
    function prepare_work_order(){
                     $this->load->view('prepare_work_order');
        }
    function send_work_order(){
         $this->load->model('maintenance_model');
         $data1['query'] = $this->maintenance_model->get_maintenenance_personel();
         $data2['result'] = $this->maintenance_model->get_maintenance_request_Id();
         $data = $data1 + $data2;
         $this->load->view('send_work_order',$data);
    }
   function send_work_order_db(){
             $data = array( 
                'MP_Id' => $this->input->post('Mp_Id'),
                'Priority_of_Task' => $this->input->post('Incident_Type'),
                'Date' => $this->input->post('Date'),
                'Mr_Id' => $this->input->post('Maintenance_Request_Id'),
                'Status' => 'Assigned'
                        );
             $this->load->model('maintenance_model');
             $result=$this->maintenance_model->register_work_order_db($data);
             if($result){
              echo "<script type='text/javascript'>alert('Data successfuly inserted into database'); window.location.href = 'http://localhost/ems/Maintenance_Manager/send_work_order'</script>";
             }else{
                echo "<script type='text/javascript'>alert('Data is not stored in database please try again'); window.location.href = 'http://localhost/ems/Maintenance_Manager/send_work_order'</script>";
             }
             
                }

    
    function job_excussion(){
          $this->load->view('Man_Job_Execussion');
    }
   function executed_job(){
        $this->load->model('Maintenance_Model');
         $data['result'] = $this->Maintenance_Model->get_executed_job();
         $this->load->view('View_Excuted_Job',$data);
   }
   function prints(){
       $Id = $this->input->post('Id');
      $this->load->model('Maintenance_Model');
      $data['result'] = $this->Maintenance_Model->get_executed_job_by_id($Id);
      $this->load->view('Print_Maintenance_Report',$data);
   }
   function view_work_order_home(){
       $this->load->view('Work_Order_Home');
      
   }
   function view_maintenance_home(){
    $this->load->model('Maintenance_Model');
    $result = $this->Maintenance_Model->get_mp();
    if($result){
        $data['count'] = $this->Maintenance_Model->get_count();
        $this->load->view('maintenance_home',$data);
    }else{
        $this->load->view('maintenance_home');
    }
      
   }
   function prepare_scedual(){
       $this->load->model('Maintenance_Model');
       $data1['data'] = $this->Maintenance_Model->get_equiman_Id();
       $result = $this->Maintenance_Model->get_mp();
       if($result){
        $data2['count'] = $this->Maintenance_Model->get_count();
            $data = $data1 + $data2;
        $this->load->view('register_schdedual',$data);
       }else{
        $this->load->view('register_schdedual',$data1);
       }
   }
   function prepare_scedualdb(){
        $this->load->model('Maintenance_Model');
       $data = array(
           'Date' => $this->input->post('date'),
           'Equipment_Id' => $this->input->post('Equipment_Id'),
                 );
      
       $query = $this->Maintenance_Model->set_schedual($data);
       if($query){
        echo "<script type='text/javascript'>alert('Data successfuly entered into database'); window.location.href = 'http://localhost/ems/Maintenance_Manager/prepare_scedual'</script>";
       }
   }
   function assign_mp(){
    $this->load->model('Maintenance_Model');
    $data1['mp'] = $this->Maintenance_Model->get_mp_ids();
    $data2['data'] = $this->Maintenance_Model->get_equiman_Id();
    $this->Maintenance_Model->update_status_pm();
    $data = $data1 + $data2;
    $this->load->view('assign_mp',$data);
   }
   function assign_mp_db(){
       $data = array(
        'Equipment_Id' => $this->input->post('Equipment_Id'),
        'Mp_Id' => $this->input->post('MP_Id')
       );
       $this->load->model('Maintenance_Model');
       $query = $this->Maintenance_Model->assign_pm($data);
       if($query){
        echo "<script type='text/javascript'>alert('Data successfuly entered into database'); window.location.href = 'http://localhost/ems/Maintenance_Manager/assign_mp'</script>";
       }
       
   }
   }
