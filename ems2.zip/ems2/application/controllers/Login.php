<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Class Login Extends CI_Controller{
       public function Index(){
                 $data['title']='Bootstrap + Codeigniter';
                    $this->load->view("Login");
           
       }
       private function no_cache(){
       
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
        
    }
    public function __construct() {	
      parent::__construct();
	$this->no_cache();				
	}
      function verify(){
         $this->form_validation->set_rules('UserName', 'User name', 'trim|required');
         $this->form_validation->set_rules('Password', 'Password', 'trim|required');
          if($this->form_validation->run()==FALSE){
                 $this->index();          }
                 else{
          $this->load->model('verification');
          $query=$this->verification->verify();
                       if($query){
           $result=$this->verification->get_position();       
           switch ($result){
               case 'MP':
                   $data=array(
				    'UserName'=>$this->input->post('UserName'),
				    'is_logged_in'=> true
					);
					$this->session->set_userdata($data);
					$UserName=$this->session->userdata('UserName');
					$data['UserName']=$UserName;
                                        $this->load->view('mp');
                                        break;
                   case 'User':
                   $data=array(
				    'UserName'=>$this->input->post('UserName'),
				    'is_logged_in'=> true
					);
					$this->session->set_userdata($data);
					$UserName=$this->session->userdata('UserName');
					$data['UserName']=$UserName;
                                        $this->load->view('user');
                                        break;
                    case 'Manager':
                             $data=array(
				    'UserName'=>$this->input->post('UserName'),
				    'is_logged_in'=> true
					);
					$this->session->set_userdata($data);
					$UserName=$this->session->userdata('UserName');
					$data['UserName']=$UserName;
                                        $this->load->view('Manager');
                                        break;
                    case 'GManager': 
                              $data = array(
                                   'UserName'=>$this->input->post('UserName'),
				    'is_logged_in'=> true
					);
					$this->session->set_userdata($data);
					$UserName=$this->session->userdata('UserName');
					$data['UserName']=$UserName;
                                        $this->load->view('GManager_Home');
                                        break;
                              }
                    } else {
                echo "<script type='text/javascript'>alert('Wrong user name and password combination'); window.location.href = 'http://localhost/ems/Login'</script>";
           }
                           
                                    }
      } 
      function Logout(){
    $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
$this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
$this->output->set_header('Pragma: no-cache');
$this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");   
          unset($_SESSION['logged_in']);  
       $this->session->sess_destroy(); 
        $this->load->view("Login");
        
      }
      }
?>