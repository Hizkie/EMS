<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class History extends CI_Controller{
    function index(){
       $this->load->model('equipments');
    $data=$this->input->post('asa');
    $data1['result']= $this->equipments->get_equip_data($data);
    $data2['incident'] =$this->equipments->get_query($data);
    $data5['mr'] = $this->equipments->get_mr($data);
    $datar['waranty']= $this->equipments->get_waranty($data); 
    $data6['report']= $this->equipments->get_mreport($data); 
    $data = $data1 + $data2 + $data5 + $datar + $data6;
    $this->load->view('History',$data);
    }
  function History_PWOrder(){
        $this->load->model('Maintenance_Model');
        $data['query']=$this->Maintenance_Model->get_history();
        $this->load->view('History_Pushed_Work_Order',$data);
  }
}
?> 