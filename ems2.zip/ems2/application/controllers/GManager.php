<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class GManager extends CI_Controller{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
    }

    
    function Register_Staff(){
        $this->load->view('register_staff');
    }
    function register_staff_db(){
         $this->form_validation->set_rules('First_Name', 'First Name', 'trim|required');
         $this->form_validation->set_rules('Last_Name', 'Last Name', 'trim|required');
         $this->form_validation->set_rules('Date_of_Employement', 'Date of employment', 'trim|required');
         $this->form_validation->set_rules('Department', 'Department', 'trim|required');
         $this->form_validation->set_rules('Specialization', 'Specialization', 'trim|required');
         $this->form_validation->set_rules('Experiance', 'Experiance', 'trim|required');
         $this->form_validation->set_rules('Position', 'Position', 'trim|required');
         $this->form_validation->set_rules('User_Name', 'User name', 'trim|required');
         $this->form_validation->set_rules('Password', 'Password', 'trim|required');
         $this->form_validation->set_rules('Confirm_Password', 'confirm password', 'trim|required|matches[Password]');
    if($this->form_validation->run()==FALSE){
                 $this->Register_Staff();       }
                 else{
                    $this->load->model('Account_Staff');
                    $query = $this->Account_Staff->chake_username();
                    IF($query){
                        $result= $this->Account_Staff->register_account_staff();
                    }else{
                       echo "<script type='text/javascript'>alert('User name already taken'); window.location.href = 'http://localhost/ems/GManager/Register_Staff'</script>";
                    }
                 }
    }
   function view_staff_detail(){
       $this->load->model('Account_Staff');
       $data['result'] = $this->Account_Staff->view_staff_detail();
       $this->load->view('Staff_Detail',$data);
   }
   function view_home(){
        $this->load->view("GManager_Home");
    }
    function view_equipment_home(){
        $this->load->view("GManager_Equipment");
    }
    function register_equipment(){
        $this->load->view("register_equipment");
    }
    function register_equipment_db(){
        $this->form_validation->set_rules('Inventory_Number', 'Inventory number', 'trim|required');
        $this->form_validation->set_rules('Equipment_Name', 'Equipment name', 'trim|required');
        $this->form_validation->set_rules('Model', 'Model', 'trim|required');
        $this->form_validation->set_rules('Department', 'Department', 'trim|required');
        $this->form_validation->set_rules('Serial_Number', 'Serial number', 'trim|required');
        $this->form_validation->set_rules('Country_of_Origin', 'Country of origin', 'trim|required');
        $this->form_validation->set_rules('Manufactured_Year', 'Manufacturer', 'trim|required');
        $this->form_validation->set_rules('Installation_Date', 'Installation Date', 'trim|required');
        $this->form_validation->set_rules('Power_Requierment', 'Power requierment', 'trim|required');
        $this->form_validation->set_rules('Shelf_Life_Time', 'Shelf life time', 'trim|required');
        $this->form_validation->set_rules('Current_State', 'Current state', 'trim|required');
        $this->form_validation->set_rules('Manufacturer', 'Manufaturer', 'trim|required');
        if($this->form_validation->run()==FALSE){
            $this->register_equipment();
        }else{
            $config['upload_path']          = './Uploads/';
            $config['allowed_types']        = 'gif|jpg|png|pdf|doc';
            $config['max_size']             = 100;
            $config['max_width']            = 1024;
            $config['max_height']           = 768;

            $this->load->library('upload', $config);
            $image_data=$this->input->post('Image');
            if ( ! $this->upload->do_upload('Image'))
            {
                echo "bad";
            }
            else
            {
                $this->load->model('equipments');
                $this->equipments->set_image($this->upload->data('full_path'),$this->input->post());
            }
        }
    }
    function register_mp(){
        $this->load->model("Account_Staff");
        $data['result'] = $this->Account_Staff->get_staff_Id();
        $this->load->view('register_mp_home',$data);
    }
    function register_mp_db(){
        $this->load->model('Account_Staff');
       $data = $this->Account_Staff->register_mp();
    }
    function view_equipment(){
        $this->load->model('equipments');
        $data['result']= $this->equipments->get_equipment();
        $this->load->view("Gmanager_view_equipment",$data);
    }
    function view_equipment_history(){
       $this->load->model('equipments');
       $data=$this->input->post('Equip_Id');
       $data1['result']= $this->equipments->get_equip_data($data);
       $data2['incident'] =$this->equipments->get_query($data);
       $data5['mr'] = $this->equipments->get_mr($data);
       $datar['waranty']= $this->equipments->get_waranty($data); 
       $data6['report']= $this->equipments->get_mreport($data); 
       $data = $data1 + $data2 + $data5 + $datar + $data6;
       $this->load->view('Gmanager_History',$data);
    }
    function register_spare(){
       $this->load->view('register_spare');
    }
    function register_sparepart(){
        $this->load->model('equipments');
        $data1['result']= $this->equipments->get_equip_id();
        $this->load->view('register_sparedb',$data1);
    }
    function set_spare_part(){
        $this->form_validation->set_rules('Name', 'Sparepart name', 'trim|required');
        $this->form_validation->set_rules('Description', 'Description', 'trim|required');
        $this->form_validation->set_rules('Measurement', 'Measurement', 'trim|required');
        $this->form_validation->set_rules('Quantity', 'Quantity', 'trim|required');
        if($this->form_validation->run()==FALSE){
            $this->register_sparepart();
        }else{
            $qu = $this->input->post('Quantity');
            if( ! filter_var($qu, FILTER_VALIDATE_INT) ){
                echo "<script type='text/javascript'>alert('Quntity must be intiger'); window.location.href = 'http://localhost/ems/GManager/register_sparepart'</script>";
              }else{
               $data = array(
                'name' => $this->input->post('Name'),
                'Description' => $this->input->post('Description'),
                'Measurement' => $this->input->post('Measurement'),
                'Quantity' => $this->input->post('Quantity'),
                'Equipment_Id' => $this->input->post('Equipment_Id')
               );
               $this->load->model('equipments');
               $data= $this->equipments->set_spare($data);
               if($data){
                echo "<script type='text/javascript'>alert('Data successfuly entered into database'); window.location.href = 'http://localhost/ems/GManager/register_sparepart'</script>";
               }
              }
        }
    }
}
