<?php
 class equipment extends CI_Controller{
      private function no_cache(){
        $this->output->set_header('Last-Modified: ' . gmdate("D, d M Y H:i:s") . ' GMT');
        $this->output->set_header('Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0');
        $this->output->set_header('Pragma: no-cache');
        $this->output->set_header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
    }
    public function __construct() {	
      parent::__construct();
	$this->no_cache();				
	}
     function index(){
        $this->load->model('equipments');
        $UserName = $this->session->userdata('UserName');
        $query= $this->equipments->view_schedual($UserName);
               if($query){
            $data['count'] = $this->equipments->get_new_preventive_count($UserName);
            $this->load->view('mp', $data);
        }else{
            $this->load->view('mp');
        }
     }
          function view_equipment(){
        $this->load->model('equipments');
        $UserName = $this->session->userdata('UserName');
        $query= $this->equipments->view_schedual($UserName);
        $data1['result'] = $this->equipments->view();
        if($query){
            $data2['count'] = $this->equipments->get_new_preventive_count($UserName);
            $data = $data1 + $data2;
            $this->load->view('view_equipment', $data);
        }else{
            $this->load->view('view_equipment',$data1);
        }
     }
     function view_man_equipment(){
         $this->load->model('equipments');
         $data['result'] = $this->equipments->view();
         $this->load->view('view_man_equipment', $data);
     }
     function view_schedual(){
        $this->load->model('equipments');
        $UserName = $this->session->userdata('UserName');
        $query= $this->equipments->view_schedual($UserName);
        $this->equipments->update_preventive_status($UserName);
        $data1['result'] = $this->equipments->get_preventive($UserName);
        if($query){
            $data2['count'] = $this->equipments->get_new_preventive_count($UserName);
            $data3['Equipment'] = $this->equipments->get_equipment();
            $data = $data1 + $data2 + $data3;
            $this->load->view('view_schedual', $data);
        }else{
            $data2['Equipment'] = $this->equipments->get_equipment();
            $data = $data1 + $data2;
            $this->load->view('view_schedual',$data);
        }
     }
     function prepare_acceptance_sheet(){
         $this->load->model('equipments');
         $data['result'] = $this->equipments->get_equipment_id();
         $this->load->view('Acceptance_Sheet',$data);
     }
     function prepare_acceptance_sheetdb(){
        $this->form_validation->set_rules('Local_Supplier', 'Local Supplier', 'trim|required');
        $this->form_validation->set_rules('Compliance', 'Compliance', 'trim|required');
        $this->form_validation->set_rules('No', 'Number of boxes received', 'trim|required');
        if($this->form_validation->run()==FALSE){
            $this->prepare_acceptance_sheet();
        }else{ 
            $data = array (
                 'Local_Supplier' => $this->input->post('Local_Supplier'),
                 'Compliance' => $this->input->post('Compliance'),
                 'No_of_Boxes_Recieved' => $this->input->post('No'),
                 'Damage' => $this->input->post('Damage'),
                 'Fitness' => $this->input->post('Fit'),
                 'Installation_Carried_Out' => $this->input->post('Installation'),
                 'Safty_Test' => $this->input->post('Safty'),
                 'User_present' => $this->input->post('Staff'),
                 'Trainnig_Given' => $this->input->post('User'),
                 'Trainnig_Satisfaction' => $this->input->post('Satisfactory'),
                 'Equipment_Acceptance' => $this->input->post('Acceptance'),
                 'Equipment_Id' => $this->input->post('Equipment_Id'),
            );
            $this->load->model('equipments');
            $query = $this->equipments->register_acceptance_sheet($data);
            if($query){
  echo "<script type='text/javascript'>alert('Data successfuly entered into database'); window.location.href = 'http://localhost/ems/equipment/prepare_acceptance_sheet'</script>";
            }else{

            }
    }
 }
 function view_acceptance_sheet(){
     $this->load->model('equipments');
    $data['result'] = $this->equipments->view_acceptance();
    $this->load->view('view_acceptance_sheet',$data);
 }
 function view_history(){
    $this->load->model('equipments');
    $data=$this->input->post('Equip_Id');
    $data1['result']= $this->equipments->get_equip_data($data);
    $data2['incident'] =$this->equipments->get_query($data);
    $data5['mr'] = $this->equipments->get_mr($data);
    $datar['waranty']= $this->equipments->get_waranty($data); 
    $data6['report']= $this->equipments->get_mreport($data); 
    $data = $data1 + $data2 + $data5 + $datar + $data6;
    $this->load->view('be_history',$data);
 }
 function pushpm(){
 
 }
}
?>
