<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Class Litrature Extends CI_Controller{
       public function Index(){
           $this->load->model('Litratures');
           $data['query']=$this->Litratures->view();
           $this->load->view('Litrature',$data);  
                  }
       function mp_litrature(){
        $this->load->model('equipments');
        $this->load->model('Litratures');
        $UserName = $this->session->userdata('UserName');
        $data1['query']=$this->Litratures->view();
        $query= $this->equipments->view_schedual($UserName);
        if($query){
            $data2['count'] = $this->equipments->get_new_preventive_count($UserName);
            $data = $data1 + $data2;
            $this->load->view('MP_Litrature',$data); ;
        }else{
            $this->load->view('MP_Litrature',$data1); 
        }
           
          
            
       }
}
 
?>