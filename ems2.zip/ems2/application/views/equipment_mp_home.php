<head>
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
  </head>
</head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto;">
        <ul class="nav">
         
        </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
        <li><a href="<?php echo base_url();?>GManager/register_staff">Register Staff</a></li>
        <li><a href="<?php echo base_url();?>GManager/register_mp">Register Maintenance Personnel</a></li>
        <li><a href="<?php echo base_url();?>GManager/view_staff_detail">View Staff Detail</a></li>
        <li><a href="<?php echo base_url();?>Login/Logout"</a>Logout</li>
        </ul> 
      </div>
      <div class='span8 main'>
        
      </div>
      </div>
  </div>
</body>