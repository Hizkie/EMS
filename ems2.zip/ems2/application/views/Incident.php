<head>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
       <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
     <script type="text/javascript" src="<?php echo base_url();?>assets/js/modal.js"></script>
     <script>
function myFunction() {
  // Declare variables 
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    } 
  }
}
</script>
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
  </head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto; ">
          <ul class="nav">
          <li><a class="actives" Style="color: white" href="<?php echo base_url();?>equipment">Equipment</a></li>
          <li><a href="<?php echo base_url();?>Spare_Part/Spare_Part_Manager">Spare Part</a></li>
          <li><a href="<?php echo base_url();?>Maintenance_Manager/job_excussion">Job Execussion</a></li>
          <li><a><a href="<?php echo base_url();?>Maintenance_Manager">Maintenance</a></li>
          <li><a href="<?php echo base_url();?>Maintenance_Manager/prepare_work_order">Work order</a></li>
           <li><a href="<?php echo base_url();?>Maintenance_Manager/prepare_work_order">Waranty</a></li>
          </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li><a href="<?php echo base_url();?>equipment/view_equipment">Equipment Information</a></li>
          <li><a Style="font-weight: bold;" href="<?php echo base_url();?>Incident/view_incident">Incident</a></li>
          <li><a href="<?php echo base_url();?>Litrature">Litrature</a></li>
          <li><a href='Login/Logout'>Logout</a></li>
        </ul>
      </div>
      <div class='span8 main'>
    <!DOCTYPE html>
                </div>
          <div class='span2 sidebar'>
        <h3>Right Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li><a href="<?php echo base_url();?>Incident/register_incident">Register Incident</a></li>
          <li><a href='#'>Another Link 2</a></li>
          <li><a href='#'>Another Link 3</a></li>
        </ul>
      </div>
    </div>
  </div>
</body>