<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
       <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
             <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
</head>
<body>
    <div class="My_Container">
        <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto; ">
          <ul class="nav">
          <li><a  href="<?php echo base_url();?>GManager/view_home">Staff</a></li>
         <li><a href="<?php echo base_url();?>GManager/view_equipment_home">Equipment</a></li>
         <li><a class="actives" Style="color: white" href="<?php echo base_url();?>GManager/register_spare">Spare Part</a></li>
          </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
        <li><a Style="font-weight: bold" href="<?php echo base_url();?>GManager/register_sparepart">Register Sparepart</a></li>
        <li><a href="<?php echo base_url();?>Login/Logout">Logout</a></li>
        </ul>
        </ul>
      </div>
            <div class='span8 main'>
    <!DOCTYPE html>
    <div class="register"> 
          <h2>Register Spare Part</h2> <br> 
          <?php echo form_open("GManager/set_spare_part");?>
          <p>Spare part name:</p><input type="text" name="Name"/>
          <p>Description:</p><input type="text" name="Description"/>   
          <p>Measurement:</p><input type="text" name="Measurement"/>
          <p>Quantity:</p><input type="text" name="Quantity"/>
          <p>Equipment Id:</p> 
          <select name="Equipment_Id">
            <?php 
              foreach($result->result() as $row)
            { 
              echo '<option value="'.$row->Equipment_Id.'">'.$row->Equipment_Id.'</option>';
            }
            ?>
            </select>
             <?php echo form_submit('Register_Spare', 'Register','class="brn btn-success"'); ?> 
            <?php echo form_close();?>
             <div class="error"> 
                  <?php echo validation_errors() ?>
             </div>
                        </div>
      </div>
    </div>
  </div>
</body>
</html>