<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
       <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
             <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
</head>
<body>
    <div class="My_Container">
        <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto; ">
          <ul class="nav">
          <li class="active"><a  href="<?php echo base_url();?>equipment">Equipment</a></li>
          <li><a href="<?php echo base_url();?>Spare_Part">Spare Part</a></li>
          <li><a href="<?php echo base_url();?>Maintenance/mp_job_excussion">Job Execussion</a></li>
          <li><a href="<?php echo base_url();?>work_order/view_work_order">Work Order</a></li>
          </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li><a href="<?php echo base_url();?>equipment/view_equipment">Equipment Information</a></li>
          <li><a Style="font-weight: bold;" href="<?php echo base_url();?>Incident">Incident</a></li>
          <li><a href="<?php echo base_url();?>Litrature">Litrature</a></li>
          <li><a href="<?php echo base_url();?>Login/Logout">Logout</a></li>
        </ul>
      </div>
            <div class='span8 main'>
    <!DOCTYPE html>
    <div class="register"> 
          <h2>Register Incident</h2> <br> 
          <?php echo form_open("Incident/register_incident_db");?>
        <?php  $Type = array(
        'Loss'       => 'Loss',
        'Teft' => 'Teft',
        'Anuthorized_Access' => 'Anuthorized_Access',
                           );
        $Description= array(
      'name'        => 'Description',
      'rows'        => '5',
      'cols'        => '10',
      'style'       => 'width:100%',
    );
        $Action_Taken= array(
      'name'        => 'Action_Taken',
      'rows'        => '5',
      'cols'        => '10',
      'style'       => 'width:100%',
    );
              
 ?>
        
          <p>Incident Type:</p><?php echo form_dropdown('Incident_Type', $Type); ?>
          <p>Date Detected:</p><input type="Date" name="Date_Detected"/>   
          <p>Date Incident Occured:</p><input type="Date" name="Incident_Date"/>  
          <p>Location:</p><input type="text" name="Location"/>   
          <p>Description:</p><?php echo form_textarea($Description); ?>   
          <p>Action Taken:</p><?php echo form_textarea($Action_Taken); ?> 
          <p>Equipment Id:</p> 
          <select name="Equipment_Id">
            <?php 
              foreach($Equipment_Id->result() as $row)
            { 
              echo '<option value="'.$row->Equipment_Id.'">'.$row->Equipment_Id.'</option>';
            }
            ?>
            </select>
             <?php echo form_submit('Register_Incident', 'Register',''); ?> 
            <?php echo form_close();?>
             <div class="error"> 
                  <?php echo validation_errors() ?>
             </div>
                        </div>
      </div>
              <div class='span2 sidebar'>
        <h3>Right Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li><a Style="font-weight: bold;" href="<?php echo base_url();?>Incident/register_incident">Send Incident</a></li>
        </ul>
      </div>
    </div>
  </div>
</body>
</html>