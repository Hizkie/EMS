<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
     <script src="<?php echo base_url();?>assets/js/jquery-1.12.4.js"></script>
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script> 
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script>
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
           <script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
</head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto;">
        <ul class="nav">
         <li><a href="<?php echo base_url();?>equipment/view_man_equipment">Equipment</a></li>
         <li><a href="<?php echo base_url();?>Spare_Part/Spare_Part_Manager">Spare Part</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/job_excussion">Job Execussion</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/view_maintenance_home">Maintenance</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/view_work_order_home">Work order</a></li>
         <li><a href="<?php echo base_url();?>Trainning">Trainning</a></li>
         <li><a href="<?php echo base_url();?>Waranty">Waranty</a></li>
         <li><a class="active" Style="color: white" href="<?php echo base_url();?>Risk_Level">Risk Level</a></li>
        </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
          <li style="font-weight: bold;"><a href="<?php echo base_url();?>Risk_Level/register_risk_level">Register Risk Level</a></li>
          <li><a href="<?php echo base_url();?>Risk_Level/view_risk_level">View Risk Level</a></li>
          <li><a href="<?php echo base_url();?>Risk_Level/Logout">Logout</a></li>
        </ul>
      </div>
      <div class='span8 main'>
              <div class="register"> 
          <h2>Register Risk Assessment</h2> <br> 
          <?php echo form_open("Risk_Level/register_rl_db");?>
        <?php  $Equipment_Function = array(
        'therapeutic_life_support' => 'Therapeutic-life support',
        'therapeutic_surgicalor_intencive_care'=>'Therapeutic-Surgicalor Intencive_Care',
        'therapeutic_physical_therapy_or_treatment' => 'Therapeutic-Physical therapy or treatment',
        'diagnostic_surgical_or_intensive_care_monitoring' => 'Diagnostic – surgical or intensive care monitoring',
        'diagnostic_other_physiological_monitoring' => 'Diagnostic – other physiological monitoring ',
        'analytical_laboratory_analytical' => 'Analytical – laboratory analytical',
        'analytical_laboratory_accessories ' => 'Analytical – laboratory accessories',
        'analytical_computer_and_related ' =>'Analytical – computer and related ',
        'miscellaneous_patient_related ' => 'Miscellaneous – patient related ',
        'Miscellaneous – non-patient related' => 'Miscellaneous – non-patient related ',
                           );
        $Associated_Risk = array(
          'potential_patient_death'   => 'Potential patient death',
          'potential_patient_injury' => 'Potential patient injury',
          'inappropriate_therapy_or_misdiagnosis' => 'Inappropriate therapy or misdiagnosis',
          'equipment_damage' => 'Equipment damage',
          'no_significant_identified_risk '=> 'No significant identified risk '
        );
        $Preventive_Maintenance_Requierment = array(
           'monthly' => 'Monthly',
           'quarterly' => 'Quarterly',
           'semi-annually'=> 'Semi-annually',
           'annually' => 'Annually',
           'not_required' => 'Not required',
        );
        $Likelihood_of_Failer = array(
            'less_than_three_months' => 'Less than three months',
            'approximately_4_6_months' => 'Approximately 4 – 6 months',
            'approximately_7_months_to_1_year' => 'Approximately 7 months to 1 year',
            'approximately_1_to_3_years' => 'Approximately 1 to 3 years',
            'approximately_more_3_years' => 'Approximately > 3 years',
        );
        $main_area_of_equipment_use = array(
          'anesthesia_care'  => 'Anesthesia/Surgical care',
          'critical_care' => 'Critical/Intensive care',
          'labs_areas' => 'Labs/Exam areas',
          'general_care_areas' => 'General care areas',
          'non_patient_areas' => 'Non-patient areas',
        );
        $Description = array(
      
      'rows'        => '5',
      'cols'        => '10',
      'style'       => 'width:100%',
    );
        $Action_Taken= array(
      'name'        => 'Action_Taken',
      'rows'        => '5',
      'cols'        => '10',
      'style'       => 'width:100%',
    );
              
 ?>
        
          <p>Equipment Function:</p><?php echo form_dropdown('Equipment_Function', $Equipment_Function); ?>
          <p>Risk associated with equipment failure :</p><?php echo form_dropdown('Associated_Risk', $Associated_Risk); ?>
          <p>Preventive Maintenance Requierment:</p><?php echo form_dropdown('Preventive_Maintenance_Requierment', $Preventive_Maintenance_Requierment); ?>
          <p>Likelihood of Failer:</p><?php echo form_dropdown('Likelihood_of_Failer', $Likelihood_of_Failer); ?>
          <p>Main Area of Equipment Use:</p><?php echo form_dropdown('main_area_of_equipment_use', $main_area_of_equipment_use); ?>
          <p>Equipment Id:</p> 
          <select name="Equipment_Id">
            <?php 
              foreach($Risk_Level->result() as $row)
            { 
              echo '<option value="'.$row->Equipment_Id.'">'.$row->Equipment_Id.'</option>';
            }
            ?>
            </select>
             <?php echo form_submit('Register_Incident', 'Register','class="btn btn-success"'); ?> 
            <?php echo form_close();?>
             <div class="error"> 
                  <?php echo validation_errors() ?>
             </div>
                        </div>
      </div>
    </div>
  </div>
</body>