<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
  </head>
  <body>
      <div class="LoginH">
          <h2>Medical Equipment Management System</h2>
      </div>
     <table border="1">  
    
   </table> 
    </body>
</html>