<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
     <script src="<?php echo base_url();?>assets/js/jquery-1.12.4.js"></script>
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script> 
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script>
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
    <style>
.button {
  font-size: 1em;
  color: blue;
  cursor: pointer;
  transition: all 0.3s ease-out;
}
.overlay {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}

.popup {
  margin: 70px auto;
  padding: 20px;
  background: #fff;
  border-radius: 5px;
  width: 30%;
  position: relative;
  transition: all 5s ease-in-out;
}

.popup h2 {
  margin-top: 0;
  color: #333;
  font-family: Tahoma, Arial, sans-serif;
}
.popup .close {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
}
.popup .close:hover {
  color: #06D85F;
}
.popup .content {
  max-height: 30%;
  overflow: auto;
}

@media screen and (max-width: 700px){
  .box{
    width: 100%;
  }
  .popup{
    width: 100%;
  }
}
    </style>
           <script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
</head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto;">
        <ul class="nav">
         <li><a href="<?php echo base_url();?>equipment/view_man_equipment">Equipment</a></li>
         <li><a class="active" Style="color: white" class="active" Style="color: white"href="<?php echo base_url();?>Spare_Part/Spare_Part_Manager">Spare Part</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/job_excussion">Job Execussion</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/view_maintenance_home">Maintenance</a></li>
         <li><a href="<?php echo base_url();?>Maintenance_Manager/view_work_order_home">Work order</a></li>
         <li><a href="<?php echo base_url();?>Trainning">Trainning</a></li>
         <li><a href="<?php echo base_url();?>Waranty">Waranty</a></li>
         <li><a href="<?php echo base_url();?>Risk_Level">Risk Level</a></li>
        </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
            <li style="font-weight: bold;"><a href="<?php echo base_url();?>/Spare_Part/View_requested_spare_Part">View Spare Part Request</a></li>
          <li><a href='<?php echo base_url();?>/Spare_Part/view_sparepart_detail'>View Spare Part Detail</a></li>
          <li><a href='<?php echo base_url();?>/Login'>Logout</a></li>
        </ul>
      </div>
      <div class='span8 main'>
          <table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Date</th>
                <th>Name of requested person</th>
                <th>Spare Part Name</th>
                <th>Measurement</th>
                <th>Quantity</th>
                <th>Assign</th>
          </tr>
        </thead>
        <tfoot>
            <tr>
               <th>Date</th>
                <th>Name of requested person</th>
                <th>Spare Part Name</th>
                <th>Measurement</th>
                <th>Quantity</th>
                <th>Assign</th>
           </tr>      
        </tfoot>
        <tbody>
             <?php foreach ($result->result() as $key  ) {?>  
          <tr>
          <?php   echo form_open('Spare_Part/assign_spare_part') ?>
         <td> <input type="text" name='date' style="background:rgba(0,0,0,0); border:none;"value=<?php  echo $key->Date; ?> readonly></td>
         <td> <?php  echo $key->Name_of_Mp; ?></td>
         <td> <?php  echo $key->Name; ?> </td>
         <td> <?php  echo $key->Measurement; ?> </td>
         <td> <input type="text" name='quantity' style="background:rgba(0,0,0,0); border:none;"value=<?php  echo $key->Quantity;?> readonly> 
              <input type="text" name='asa' style="display: none" value=<?php echo $key->Spare_Part_Request_Id; ?>></br>
              <input type="text" name='Sp_Id' style="display: none" value=<?php echo $key->Spare_Part_Id; ?>></br>
              <td><?php echo form_submit('Assign', 'Assign','class="btn btn-success"'); ?></td> 
             <?php echo form_close(); }?>
               </tr>
     </tbody>
    </table>
      </div>
 </div>
     </div>
</body>


