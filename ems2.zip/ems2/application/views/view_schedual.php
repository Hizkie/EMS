
<head>
   <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="<?php echo base_url();?>assets/css/bootstrap.css" rel="stylesheet">
       <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/Casto.css" rel="stylesheet">
     <link href="<?php echo base_url();?>assets/css/jquery.dataTables.min.css" rel="stylesheet">
     <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"> </script>
     <script src="<?php echo base_url();?>assets/js/bootstrap.js"> </script>
     <script src="<?php echo base_url();?>assets/js/jquery-1.12.4.js"></script>
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script> 
     <script src="<?php echo base_url();?>assets/js/jquery.dataTables.min.js"> </script>
     <script type="text/javascript">
        function noBack()
         {
             window.history.forward()
         }
        noBack();
        window.onload = noBack;
        window.onpageshow = function(evt) { if (evt.persisted) noBack() }
        window.onunload = function() { void (0) }
    </script>
        <script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>
        <!-- Bootstrap CSS -->
    <title>Equipment Management System</title>
  </head>
<body>
  <div class="My_Container">
    <h1>Hospital Equipment Management System</h1>
    <div class='navbar navbar-inverse' Style="margin-left: 0px">
      <div class='navbar-inner nav-collapse' style="height: auto; ">
          <ul class="nav">
          <li class="active"><a  href="<?php echo base_url();?>equipment">Equipment</a></li>
          <li><a href="<?php echo base_url();?>Spare_Part">Spare Part</a></li>
          <li><a href="<?php echo base_url();?>Maintenance/mp_job_excussion">Job Execussion</a></li>
          <li><a href="<?php echo base_url();?>work_order/view_work_order">Work Order</a></li>
          </ul>
      </div>
    </div>
    <div id='content' class='row-fluid'>
    <div class='span2 sidebar'>
        <h3>Left Sidebar</h3>
        <ul class="nav nav-tabs nav-stacked">
         <li><a href="<?php echo base_url();?>equipment/view_equipment">Equipment Information</a></li>
         <li><a href="<?php echo base_url();?>Incident/mp_incident">Incident</a></li>
          <li><a href="<?php echo base_url();?>Litrature/mp_litrature">Litrature</a></li>
          <li><a style="font-weight: bold" href="<?php echo base_url();?>equipment/view_schedual">Preventive maintenance schedual</a></li>
           <li><a href='<?php echo base_url();?>Login/Logout'>Logout</a></li>
        </ul>
      </div>
      <div class='span8 main'>
<table id="example" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Inventory Number</th>
                <th>Serial Number</th>
                <th>Department</th>
                <th>Push</th>
          </tr>
        </thead>
        <tfoot>
            <tr>
                 <th>Name</th>
                <th>Inventory Number</th>
                <th>Serial Number</th>
                <th>Department</th>
                <th>Push</th>
                </tr>
        </tfoot>
        <tbody>
            <?php  
           foreach ($result->result() as $key  ) {?>  
       <tr>
         <td> <?php  echo $key->Equipment_Name; ?> </td> 
         <td> <?php  echo $key->Inventory_Number; ?> </td> 
         <td> <?php  echo $key->Serial_Number; ?> </td> 
         <td> <?php  echo $key->Department; ?> </td> 
        <td> <?php echo form_open('equipment/pushpm') ?>
            <input type="text" name='Equipment_Id'  style="display: none" value=<?php echo $key->Equipment_Id; ?> />
            <?php echo form_submit('Push', 'Push','class="btn btn-success"' ); ?></td>
           <?php form_close(); }?>
         </tbody>
    </table>
            </div>
       </div>
  </div>
        <script>
$('.SeeMore2').click(function(){
		var $this = $(this);
		$this.toggleClass('SeeMore2');
		if($this.hasClass('SeeMore2')){
			$this.text('See More');			
		} else {
			$this.text('See Less');
		}
	});
</script>
</body>