/**
 * Helper css_url()
 *
 * @access public
 * @param string
 * @return string
 */
if ( ! function_exists('css_url'))
{
 function css_url($uri)
 {
  $_ci = get_instance();
  return $_ci->config->base_url('assets/css/'.$uri);
 }
}  

// ------------------------------------------------------------------------
<?php 
/**
 * Helper js_url()
 *
 * @access public
 * @param string
 * @return string
 */
if ( ! function_exists('js_url'))
{
 function js_url($uri)
 {
  $_ci = get_instance();
  return $_ci->config->base_url('assets/js/'.$uri);
 }
}  ?>